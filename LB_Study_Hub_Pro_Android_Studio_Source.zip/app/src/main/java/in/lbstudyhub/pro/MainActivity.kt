package in.lbstudyhub.pro

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.platform.LocalContext
import android.widget.Toast

data class StudyItem(val title: String, val detail: String, val offline: Boolean = true)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { LBStudyHubProApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LBStudyHubProApp() {
    var selected by remember { mutableStateOf("Home") }
    val context = LocalContext.current
    val sections = listOf("Study Material", "Mock Tests", "Video Lectures", "Downloads")
    val sampleItems = listOf(
        StudyItem("General Knowledge", "Notes and practice material"),
        StudyItem("Rajasthan GK", "PDF notes and important questions"),
        StudyItem("Reasoning", "Topic-wise notes and exercises"),
        StudyItem("Geography", "Maps, concepts and study notes")
    )
    MaterialTheme {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("LB Study Hub Pro", fontWeight = FontWeight.Bold)
                            Text("Learn • Practice • Achieve", style = MaterialTheme.typography.labelSmall)
                        }
                    },
                    actions = {
                        IconButton(onClick = {
                            Toast.makeText(context, "Updates section coming soon", Toast.LENGTH_SHORT).show()
                        }) { Icon(Icons.Default.Notifications, contentDescription = "Notifications") }
                    }
                )
            },
            bottomBar = {
                NavigationBar {
                    listOf("Home", "Study", "Tests", "Profile").forEach { item ->
                        NavigationBarItem(
                            selected = selected == item,
                            onClick = { selected = item },
                            icon = {
                                Icon(
                                    when (item) {
                                        "Study" -> Icons.Default.MenuBook
                                        "Tests" -> Icons.Default.Quiz
                                        "Profile" -> Icons.Default.Person
                                        else -> Icons.Default.Home
                                    }, contentDescription = item
                                )
                            },
                            label = { Text(item) }
                        )
                    }
                }
            }
        ) { padding ->
            when (selected) {
                "Home" -> HomeScreen(sections, sampleItems, Modifier.padding(padding))
                "Study" -> StudyScreen(sampleItems, Modifier.padding(padding))
                "Tests" -> PlaceholderScreen("Mock Tests", "यहाँ विषयवार mock tests जोड़े जा सकते हैं।", Modifier.padding(padding))
                else -> PlaceholderScreen("Profile", "आपकी प्रोफाइल और ऐप सेटिंग्स यहाँ होंगी।", Modifier.padding(padding))
            }
        }
    }
}

@Composable
fun HomeScreen(sections: List<String>, items: List<StudyItem>, modifier: Modifier = Modifier) {
    LazyColumn(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Column(Modifier.padding(18.dp)) {
                    Text("नमस्ते! 👋", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Text("अपनी पढ़ाई आज से शुरू करें।")
                }
            }
        }
        item { Text("मुख्य सुविधाएँ", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
        items(sections) { section ->
            Card {
                Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.School, contentDescription = null)
                    Spacer(Modifier.width(12.dp))
                    Text(section, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.weight(1f))
                    Icon(Icons.Default.ChevronRight, contentDescription = null)
                }
            }
        }
        item { Text("लोकप्रिय विषय", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
        items(items) { StudyCard(it) }
    }
}

@Composable
fun StudyScreen(items: List<StudyItem>, modifier: Modifier = Modifier) {
    LazyColumn(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("Study Material", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }
        items(items) { StudyCard(it) }
        item {
            Text(
                "Offline PDF जोड़ने के लिए app/src/main/assets/pdfs में अपनी PDF रखें। " +
                "Online सामग्री के लिए README में दिए manifest format का उपयोग करें।",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@Composable
fun StudyCard(item: StudyItem) {
    Card(Modifier.fillMaxWidth().clickable { }) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.PictureAsPdf, contentDescription = null)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(item.title, fontWeight = FontWeight.SemiBold)
                Text(item.detail, style = MaterialTheme.typography.bodySmall)
            }
            Text(if (item.offline) "Offline" else "Online", style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
fun PlaceholderScreen(title: String, message: String, modifier: Modifier = Modifier) {
    Column(
        modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(Icons.Default.School, contentDescription = null, modifier = Modifier.size(48.dp))
        Spacer(Modifier.height(12.dp))
        Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text(message)
    }
}
