# LB Study Hub Pro — Starter Android Project

यह एक नया Android Studio starter project है। यह पुराने APK का modified/unlocked version नहीं है।
इसमें कोई Key Generation या Key Verification feature नहीं है।

## चलाने का तरीका
1. Android Studio (Jellyfish या नया) खोलें।
2. `LB_Study_Hub_Pro` folder को Open करें।
3. Gradle Sync पूरा होने दें।
4. Android device/emulator connect करके Run दबाएँ।

## Offline PDF जोड़ना
`app/src/main/assets/pdfs/` folder बनाएँ और अपनी अधिकृत PDF files रखें।
अगले development step में PDF list और built-in viewer जोड़ा जा सकता है।

## Online content का प्रस्तावित manifest
अपने HTTPS server पर `content.json` रखें:
```json
{
  "items": [
    {
      "title": "Rajasthan GK",
      "type": "pdf",
      "url": "https://example.com/rajasthan-gk.pdf"
    },
    {
      "title": "Introduction video",
      "type": "video",
      "url": "https://example.com/lesson.mp4"
    }
  ]
}
```
अगले चरण में app में manifest fetch, download manager, local database/cache और PDF/video viewer जोड़े जा सकते हैं।

## जरूरी
- `example.com` को अपने HTTPS server के URL से बदलें।
- केवल वही PDFs/videos जोड़ें जिनका उपयोग/वितरण करने का अधिकार आपके पास है।
- यह starter UI है; online sync, real mock-test engine, admin panel और PDF viewer अभी आगे जोड़ने होंगे।
